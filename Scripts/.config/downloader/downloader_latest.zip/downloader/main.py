import traceback
import sys
from pathlib import Path
from downloader.config import ConfigReader
from downloader.local_repository import LocalRepositoryProvider
from downloader.logger import FileLoggerDecorator, PrintLogger
from downloader.full_run_service_factory import FullRunServiceFactory
def main(env):
    local_repository_provider = LocalRepositoryProvider()
    logger = FileLoggerDecorator(PrintLogger(), local_repository_provider)
    logger.print('START!')
    logger.print()
    try:
        exit_code = execute_full_run(
            FullRunServiceFactory(logger, local_repository_provider=local_repository_provider),
            ConfigReader(logger, env),
            sys.argv
        )
    except Exception as _:
        logger.print(traceback.format_exc())
        exit_code = 1
    logger.finalize()
    return exit_code
def execute_full_run(full_run_service_factory, config_reader, argv):
    config = config_reader.read_config(config_reader.calculate_config_path(str(Path().resolve())))
    runner = full_run_service_factory.create(config)
    if len(argv) == 2 and (argv[1] == '--print-drives' or argv[1] == '-pd'):
        exit_code = runner.print_drives()
    else:
        exit_code = runner.full_run()
    return exit_code
