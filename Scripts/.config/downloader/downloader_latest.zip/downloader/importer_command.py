from typing import Dict, Any
from downloader.constants import K_OPTIONS, K_DEFAULT_DB_ID, K_BASE_PATH, K_USER_DEFINED_OPTIONS, K_FILTER
class ImporterCommand:
    def __init__(self, config: Dict[str, Any], user_defined_options):
        self._config = config
        self._user_defined_options = user_defined_options
        self._parameters = []
    def add_db(self, db, store, ini_description):
        config = self._config.copy()
        for key, option in db.default_options.items():
            if key not in self._user_defined_options or (key == K_FILTER and '[mister]' in option.lower()):
                config[key] = option
        if K_OPTIONS in ini_description:
            ini_description[K_OPTIONS].apply_to_config(config)
        if not store.read_only().has_base_path():
            store.write_only().set_base_path(config[K_BASE_PATH])
        if config[K_FILTER] is not None and '[mister]' in config[K_FILTER].lower():
            mister_filter = '' if K_FILTER not in self._config or self._config[K_FILTER] is None else self._config[K_FILTER].lower()
            config[K_FILTER] = config[K_FILTER].lower().replace('[mister]', mister_filter).strip()
        entry = (db, store, config)
        if db.db_id == self._config[K_DEFAULT_DB_ID]:
            self._parameters = [entry, *self._parameters]
        else:
            self._parameters.append(entry)
        return self
    def read_dbs(self):
        return self._parameters
class ImporterCommandFactory:
    def __init__(self, config):
        self._config = config
    def create(self) -> ImporterCommand:
        return ImporterCommand(self._config, self._config[K_USER_DEFINED_OPTIONS])
