from downloader.store_migrator import MigrationBase
class MigrationV1(MigrationBase):
    version = 1
    def migrate(self, local_store):
        """create 'dbs' field"""
        db_ids = list(local_store.keys())
        dbs = dict()
        for db_id in db_ids:
            dbs[db_id] = local_store[db_id]
            local_store.pop(db_id)
        local_store['dbs'] = dbs
        """create 'zips' fields"""
        for db_id in local_store['dbs']:
            local_store['dbs'][db_id]['zips'] = dict()
