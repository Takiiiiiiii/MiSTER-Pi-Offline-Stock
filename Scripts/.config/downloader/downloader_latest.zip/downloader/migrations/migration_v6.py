from downloader.store_migrator import MigrationBase
class MigrationV6(MigrationBase):
    def __init__(self, file_system_factory):
        self._file_system_factory = file_system_factory
    version = 6
    def migrate(self, local_store):
        """remove shadow masks folder because it might contain empty folders because of issue #7"""
        """DISABLED: disabled because was considered detrimental. Check git history to see previous code. It's safe to disable."""
        pass
