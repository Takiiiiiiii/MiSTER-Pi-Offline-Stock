import subprocess
from abc import ABC
class OsUtils(ABC):
    def sync(self):
        """send sync signal to the OS"""
    def reboot(self):
        """send reboot signal to the OS"""
class LinuxOsUtils(OsUtils):
    def sync(self):
        subprocess.run(['sync'], shell=False, stderr=subprocess.STDOUT)
    def reboot(self):
        subprocess.run(['reboot', 'now'], shell=False, stderr=subprocess.STDOUT)