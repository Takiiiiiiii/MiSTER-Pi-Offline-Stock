class IniParser:
    def __init__(self, ini_args):
        self._ini_args = ini_args
    def get_string(self, key, default):
        result = self._ini_args.get(key, default)
        if result is None:
            return None
        return self._ini_args.get(key, default).strip('"\' ')
    def get_bool(self, key, default):
        return bool(strtobool(self.get_string(key, 'true' if default else 'false')))
    def get_int(self, key, default):
        result = self.get_string(key, None)
        if result is None:
            return default
        return to_int(result, default)
    def get_str_list(self, key, default):
        result = [s for s in [s.strip('"\' ') for s in self.get_string(key, '')] if s != '']
        if len(result) > 0:
            return result
        else:
            return default
    def get_int_list(self, key, default):
        result = [s for s in [to_int(s, None) for s in self.get_str_list(key, [])] if s is not None]
        if len(result) > 0:
            return result
        else:
            return default
    def has(self, key):
        return self._ini_args.get(key) is not None
def to_int(n, default):
    try:
        return int(n)
    except ValueError as _:
        if isinstance(default, Exception):
            raise default
        return default
def strtobool(val: str):
    val = val.lower()
    if val in ('y', 'yes', 't', 'true', 'on', '1'):
        return 1
    elif val in ('n', 'no', 'f', 'false', 'off', '0'):
        return 0
    else:
        raise ValueError("invalid truth value %r" % (val,))
