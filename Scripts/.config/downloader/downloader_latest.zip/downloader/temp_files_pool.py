import os
class TempFilesPool:
    def __init__(self, file_system):
        self._file_system = file_system
        self._temp_files = []
    def make_temp_file(self):
        temp_file = self._file_system.unique_temp_filename()
        self._temp_files.append(temp_file)
        return temp_file.value
    def __enter__(self):
        return self
    def __exit__(self, exception_type, exception_value, traceback):
        self.cleanup()
    def cleanup(self):
        for temp_file in self._temp_files:
            if os.path.exists(temp_file.value):
                os.unlink(temp_file.value)
            temp_file.close()
        self._temp_files = []
