from abc import ABC, abstractmethod
class StoreMigrator:
    def __init__(self, migration_list, logger):
        self._migrations = migration_list
        self._logger = logger
    def migrate(self, local_store):
        self._logger.bench('Migration start.')
        current_version = local_store.get('migration_version', 0)
        if current_version >= len(self._migrations):
            self._logger.bench('Migration not necessary, early return.')
            return
        for i in range(current_version, len(self._migrations), 1):
            if (self._migrations[i].version - 1) != i:
                raise WrongMigrationException('Migration error: (%s -1) != %s' % (self._migrations[i].version, i))
            self._logger.debug('Running migration version %s.' % self._migrations[i].version)
            self._migrations[i].migrate(local_store)
        local_store['migration_version'] = self.latest_migration_version()
        self._logger.bench('Migration done.')
    def latest_migration_version(self):
        return len(self._migrations)
def make_new_local_store(store_migrator):
    return {
        'dbs': {},
        'migration_version': store_migrator.latest_migration_version(),
        'internal': True
    }
class WrongMigrationException(Exception):
    pass
class MigrationBase(ABC):
    @property
    @abstractmethod
    def version(self):
        """Version of the migration object"""
    def migrate(self, local_store):
        """Migrate the local store"""
