class FileDownloadException(Exception): pass
