from dataclasses import dataclass, field
from typing import Dict, Any, Optional
from downloader.job_system import Job, JobSystem
@dataclass
class FetchFileJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    path: str
    description: Dict[str, Any]
    hash_check: bool
    after_validation: Optional[Job] = None
