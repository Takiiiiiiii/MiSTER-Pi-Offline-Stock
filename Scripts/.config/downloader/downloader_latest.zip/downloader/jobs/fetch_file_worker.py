from typing import Dict, Any
from downloader.jobs.fetch_file_job import FetchFileJob
from downloader.jobs.validate_file_job import ValidateFileJob
from downloader.jobs.worker_context import DownloaderWorker
from downloader.jobs.errors import FileDownloadException
class FetchFileWorker(DownloaderWorker):
    def initialize(self): self._ctx.job_system.register_worker(FetchFileJob.type_id, self)
    def reporter(self): return self._ctx.file_download_reporter
    def operate_on(self, job: FetchFileJob):
        file_path, description = job.path, job.description
        self._fetch_file(file_path, description)
        self._ctx.job_system.push_job(ValidateFileJob(fetch_job=job), priority=1)
    def _fetch_file(self, file_path: str, description: Dict[str, Any]):
        target_path = self._ctx.file_system.download_target_path(self._ctx.target_path_repository.create_target(file_path, description))
        with self._ctx.http_gateway.open(description['url']) as (final_url, in_stream):
            description['url'] = final_url
            if in_stream.status != 200:
                raise FileDownloadException(f'Bad http status! {file_path}: {in_stream.status}')
            self._ctx.file_system.write_incoming_stream(in_stream, target_path)
