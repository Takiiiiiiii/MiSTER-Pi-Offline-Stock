from dataclasses import dataclass, field
from downloader.job_system import Job, JobSystem
from downloader.jobs.fetch_file_job import FetchFileJob
@dataclass
class ValidateFileJob(Job):
    type_id: int = field(init=False, default=JobSystem.get_job_type_id())
    fetch_job: FetchFileJob
    def retry_job(self): return self.fetch_job
