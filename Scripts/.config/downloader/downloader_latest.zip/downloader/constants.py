from enum import unique, Enum
DEFAULT_CACERT_FILE = '/etc/ssl/certs/cacert.pem'
DEFAULT_CURL_SSL_OPTIONS = '--cacert %s' % DEFAULT_CACERT_FILE
DEFAULT_UPDATE_LINUX_ENV = 'undefined'
DEFAULT_MINIMUM_SYSTEM_FREE_SPACE_MB = 512
DEFAULT_MINIMUM_EXTERNAL_FREE_SPACE_MB = 128
DISTRIBUTION_MISTER_DB_URL = 'https://raw.githubusercontent.com/MiSTer-devel/Distribution_MiSTer/main/db.json.zip'
DISTRIBUTION_MISTER_DB_ID = 'distribution_mister'
FILE_MiSTer = 'MiSTer'
FILE_PDFViewer = 'linux/pdfviewer'
FILE_lesskey = 'linux/lesskey'
FILE_glow = 'linux/glow'
FILE_MiSTer_new = 'MiSTer.new'
FILE_MiSTer_old = '.MiSTer.old'
FILE_menu_rbf = 'menu.rbf'
FILE_MiSTer_ini = 'MiSTer.ini'
FILE_MiSTer_alt_ini = 'MiSTer_alt.ini'
FILE_MiSTer_alt_1_ini = 'MiSTer_alt_1.ini'
FILE_MiSTer_alt_2_ini = 'MiSTer_alt_2.ini'
FILE_MiSTer_alt_3_ini = 'MiSTer_alt_3.ini'
FOLDER_linux = 'linux'
FOLDER_saves = 'saves'
FOLDER_savestates = 'savestates'
FOLDER_screenshots = 'screenshots'
FOLDER_gamecontrollerdb = 'linux/gamecontrollerdb'
FILE_gamecontrollerdb = 'linux/gamecontrollerdb/gamecontrollerdb.txt'
FILE_gamecontrollerdb_user = 'linux/gamecontrollerdb/gamecontrollerdb_user.txt'
FILE_yc_txt = 'yc.txt'
FILE_downloader_storage_zip = 'Scripts/.config/downloader/downloader.json.zip'
FILE_downloader_storage_json = 'Scripts/.config/downloader/downloader.json'
FILE_downloader_external_storage = '.downloader_db.json'
FILE_downloader_last_successful_run = 'Scripts/.config/downloader/%s.last_successful_run'
FILE_downloader_log = 'Scripts/.config/downloader/%s.log'
FILE_downloader_ini = '/media/fat/downloader.ini'
FILE_downloader_launcher_script = 'Scripts/downloader.sh'
FILE_MiSTer_version = '/MiSTer.version'
FILE_Linux_7z = '/media/fat/linux/7za'
FILE_Linux_user_files = [
    ('/media/fat/linux/hostname', '/etc/hostname'),
    ('/media/fat/linux/hosts', '/etc/hosts'),
    ('/media/fat/linux/interfaces', '/etc/network/interfaces'),
    ('/media/fat/linux/resolv.conf', '/etc/resolv.conf'),
    ('/media/fat/linux/dhcpcd.conf', '/etc/dhcpcd.conf'),
    ('/media/fat/linux/fstab', '/etc/fstab'),
]
FILE_downloader_needs_reboot_after_linux_update = '/tmp/downloader_needs_reboot_after_linux_update'
FILE_mister_downloader_needs_reboot = '/tmp/MiSTer_downloader_needs_reboot'
HASH_file_does_not_exist = 'file_does_not_exist'
STORAGE_PRIORITY_PREFER_SD = 'prefer_sd'
STORAGE_PRIORITY_PREFER_EXTERNAL = 'prefer_external'
STORAGE_PRIORITY_OFF = 'off'
MEDIA_USB0 = '/media/usb0'
MEDIA_USB1 = '/media/usb1'
MEDIA_USB2 = '/media/usb2'
MEDIA_USB3 = '/media/usb3'
MEDIA_USB4 = '/media/usb4'
MEDIA_USB5 = '/media/usb5'
MEDIA_FAT_CIFS = '/media/fat/cifs'
MEDIA_FAT = '/media/fat'
STORAGE_PATHS_PRIORITY_SEQUENCE = [
    MEDIA_USB0,
    MEDIA_USB1,
    MEDIA_USB2,
    MEDIA_USB3,
    MEDIA_USB4,
    MEDIA_USB5,
    MEDIA_FAT_CIFS,
    MEDIA_FAT
]
K_BASE_PATH = 'base_path'
K_BASE_SYSTEM_PATH = 'base_system_path'
K_STORAGE_PRIORITY = 'storage_priority'
K_DATABASES = 'databases'
K_ALLOW_DELETE = 'allow_delete'
K_ALLOW_REBOOT = 'allow_reboot'
K_UPDATE_LINUX = 'update_linux'
K_DOWNLOADER_THREADS_LIMIT = 'downloader_threads_limit'
K_DOWNLOADER_TIMEOUT = 'downloader_timeout'
K_DOWNLOADER_RETRIES = 'downloader_retries'
K_ZIP_FILE_COUNT_THRESHOLD = 'zip_file_count_threshold'
K_ZIP_ACCUMULATED_MB_THRESHOLD = 'zip_accumulated_mb_threshold'
K_FILTER = 'filter'
K_VERBOSE = 'verbose'
K_CONFIG_PATH = 'config_path'
K_LOGFILE = 'logfile'
K_USER_DEFINED_OPTIONS = 'user_defined_options'
K_CURL_SSL = 'curl_ssl'
K_DB_URL = 'db_url'
K_SECTION = 'section'
K_OPTIONS = 'options'
K_DEBUG = 'debug'
K_FAIL_ON_FILE_ERROR = 'fail_on_file_error'
K_COMMIT = 'commit'
K_DEFAULT_DB_ID = 'default_db_id'
K_START_TIME = 'start_time'
K_IS_PC_LAUNCHER = 'is_pc_launcher'
K_MINIMUM_SYSTEM_FREE_SPACE_MB = 'minimum_system_free_space_mb'
K_MINIMUM_EXTERNAL_FREE_SPACE_MB = 'minimum_external_free_space_mb'
KENV_DOWNLOADER_LAUNCHER_PATH = 'DOWNLOADER_LAUNCHER_PATH'
KENV_DOWNLOADER_INI_PATH = 'DOWNLOADER_INI_PATH'
KENV_CURL_SSL = 'CURL_SSL'
KENV_COMMIT = 'COMMIT'
KENV_ALLOW_REBOOT = 'ALLOW_REBOOT'
KENV_UPDATE_LINUX = 'UPDATE_LINUX'
KENV_DEFAULT_DB_URL = 'DEFAULT_DB_URL'
KENV_DEFAULT_DB_ID = 'DEFAULT_DB_ID'
KENV_DEFAULT_BASE_PATH = 'DEFAULT_BASE_PATH'
KENV_FORCED_BASE_PATH = 'FORCED_BASE_PATH'
KENV_PC_LAUNCHER = 'PC_LAUNCHER'
KENV_DEBUG = 'DEBUG'
KENV_FAIL_ON_FILE_ERROR = 'FAIL_ON_FILE_ERROR'
KENV_LOGFILE = 'LOGFILE'
@unique
class PathType(Enum):
    FILE = 0
    FOLDER = 1
