import datetime
import tempfile
import sys
import time
import traceback
from abc import ABC, abstractmethod
from downloader.constants import K_VERBOSE, K_START_TIME
class Logger(ABC):
    @abstractmethod
    def configure(self, _config):
        """makes logs more verbose"""
    @abstractmethod
    def print(self, *args, sep='', end='\n', file=sys.stdout, flush=True):
        """print always"""
    @abstractmethod
    def debug(self, *args, sep='', end='\n', flush=True):
        """print only to debug target"""
    @abstractmethod
    def bench(self, label):
        """print only to debug target"""
    def finalize(self):
        """to be called at the very end, should not call any method after this one"""
class PrintLogger(Logger):
    @staticmethod
    def make_configured(config):
        logger = PrintLogger()
        logger.configure(config)
        return logger
    def __init__(self):
        self._verbose_mode = False
        self._start_time = None
    def configure(self, config):
        if config[K_VERBOSE]:
            self._verbose_mode = True
            self._start_time = config[K_START_TIME]
    def print(self, *args, sep='', end='\n', file=sys.stdout, flush=True):
        self._do_print(*args, sep=sep, end=end, file=file, flush=flush)
    def debug(self, *args, sep='', end='\n', flush=True):
        if self._verbose_mode:
            exceptions = []
            for a in args:
                if isinstance(a, Exception):
                    exceptions.append(a)
            if len(exceptions) > 0:
                args = list(set(args) - set(exceptions))
                for e in exceptions:
                    self._do_print("".join(traceback.format_exception(type(e), e, e.__traceback__)), sep=sep, end=end, file=sys.stdout, flush=flush)
            self._do_print(*args, sep=sep, end=end, file=sys.stdout, flush=flush)
    def bench(self, label):
        if self._start_time is not None:
            self._do_print('%s| %s' % (str(datetime.timedelta(seconds=time.time() - self._start_time))[0:-4], label), sep='', end='\n', file=sys.stdout, flush=True)
    def finalize(self):
        pass
    def _do_print(self, *args, sep, end, file, flush):
        try:
            print(*args, sep=sep, end=end, file=file, flush=flush)
        except UnicodeEncodeError:
            pack = []
            for a in args:
                pack.append(a.encode('utf8', 'surrogateescape'))
            print(*pack, sep=sep, end=end, file=file, flush=flush)
        except BaseException as error:
            print('An unknown exception occurred during logging: %s' % str(error))
class NoLogger(Logger):
    def print(self, *args, sep='', end='\n', file=sys.stdout, flush=False):
        pass
    def debug(self, *args, sep='', end='\n', file=sys.stdout, flush=False):
        pass
    def bench(self, _label):
        pass
    def configure(self, _config):
        pass
    def finalize(self):
        pass
class FileLoggerDecorator(Logger):
    def __init__(self, decorated_logger, local_repository_provider):
        self._decorated_logger = decorated_logger
        self._logfile = tempfile.NamedTemporaryFile('w', delete=False)
        self._local_repository_provider = local_repository_provider
    def configure(self, config):
        self._decorated_logger.configure(config)
    def finalize(self):
        self._decorated_logger.finalize()
        if self._logfile is None:
            return
        self._logfile.close()
        self._local_repository_provider.local_repository.save_log_from_tmp(self._logfile.name)
        self._logfile = None
    def print(self, *args, sep='', end='\n', file=sys.stdout, flush=True):
        self._decorated_logger.print(*args, sep=sep, end=end, file=file, flush=flush)
        self._do_print_in_file(*args, sep=sep, end=end, flush=flush)
    def debug(self, *args, sep='', end='\n', flush=True):
        self._decorated_logger.debug(*args, sep=sep, end=end, flush=flush)
        self._do_print_in_file(*args, sep=sep, end=end, flush=flush)
    def bench(self, label):
        self._decorated_logger.bench(label)
    def _do_print_in_file(self, *args, sep, end, flush):
        if self._logfile is not None:
            print(*args, sep=sep, end=end, file=self._logfile, flush=flush)
class DebugOnlyLoggerDecorator(Logger):
    def __init__(self, decorated_logger):
        self._decorated_logger = decorated_logger
    def configure(self, config):
        self._decorated_logger.configure(config)
    def print(self, *args, sep='', end='\n', file=sys.stdout, flush=True):
        """Calls debug instead of print"""
        self._decorated_logger.debug(*args, sep=sep, end=end, flush=flush)
    def debug(self, *args, sep='', end='\n', flush=True):
        self._decorated_logger.debug(*args, sep=sep, end=end, flush=flush)
    def bench(self, label):
        self._decorated_logger.bench(label)
    def finalize(self):
        self._decorated_logger.finalize()
